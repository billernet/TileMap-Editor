IndexToCoordinates = function (index, rowLength) {

    var x = index % rowLength;
    var y = Math.floor(index / rowLength);

    return new Coordinate(x, y);
}

CoordinatesToIndex = function (x, y, rowLength) {
    return (y * rowLength) + x;
}

function Coordinate(x, y) {

    var coord = {
        X: x,
        Y: y
    }

    return coord;
}

CoordinatesFromMouseEvent = function (event, tileDimensions) {
    var offset = $(event.target).offset();

    var coord = new Coordinate();
    coord.X = Math.floor((event.pageX - offset.left) / tileDimensions[0]);
    coord.Y = Math.floor((event.pageY - offset.top) / tileDimensions[1]);

    return coord;
}

CreatePalletMap = function (tiles) {
    var map = [];
    for (var i = 0; i < tiles; i++)
    {
        map.push(i);
    }
    return map;
}