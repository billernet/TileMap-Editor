 var demo1 = { 
    tileSet : "tileset.png",
    mainMap : { 
        mapRowLength : 24,
        palletRowLength: 7,
    },
    pallet : {
        map : [],
        mapRowLength : 7,
        palletRowLength : 7,
        width: 224,
        height: 160                
    }
};
demo1.pallet.map = CreatePalletMap(7*5);

var demo2 = { 
    tileSet : "detail_tile.png",
    mainMap : { 
        mapRowLength : 24,
        palletRowLength: 12,
    },
    pallet : {
        map : [],
        mapRowLength : 12,
        palletRowLength : 12,
        width: 384,
        height: 224                
    }
};
demo2.pallet.map = CreatePalletMap(12*12);

var dune2 = {
    tileSet : "dune2_tiles.png",
    mainMap : { 
        mapRowLength : 48,
        palletRowLength: 44,
        tileDimensions : [16, 16]
    },
    pallet : {
        map : [],
        mapRowLength : 44,
        palletRowLength : 44,
        width: 704,
        height: 160,
        tileDimensions : [16, 16]  
    }
};
dune2.pallet.map = CreatePalletMap(44*10);

var chaosEngine = {
    tileSet : "ChaosEngineTileSet.png",
    mainMap : { 
        mapRowLength : 48,
        palletRowLength: 20,
        tileDimensions : [16, 16],
        cellSpace: 1,
        edgeSpace: 1
    },
    pallet : {
        map : [],
        mapRowLength : 20,
        palletRowLength : 20,
        width: 320,
        height: 304,
        tileDimensions : [16, 16],
        cellSpace: 1,
        edgeSpace: 1
    }
};
chaosEngine.pallet.map = CreatePalletMap(20*19);

var mario = {
    tileSet : "mario.png",
    mainMap : { 
        mapRowLength : 48,
        palletRowLength: 19,
        tileDimensions : [16, 16]
    },
    pallet : {
        map : [],
        mapRowLength : 19,
        palletRowLength : 19,
        width: 304,
        height: 192,
        tileDimensions : [16, 16]
    }
}
mario.pallet.map = CreatePalletMap(19*12);